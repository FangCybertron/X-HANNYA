function rankbooster.onClick()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/rankbooster.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/rankbooster.zip")
end

function configantilag.onClick()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/configsmooth.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/configsmooth.zip")
end

function nightmode.onClick()
  nightmode.show()
end
nightmode = PopupMenu(activity, nightmode)
menu = nightmode.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/nightmodebackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/nightmodebackup.zip")
end
menu.add("• Install").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/nightmode.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/nightmode.zip")
end

function miya.onClick()
  miya.show()
end
miya = PopupMenu(activity, miya)
menu = miya.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyabackup.zip")
end
menu.add("• Legend").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyalegends.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyalegends.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyaepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyaepic.zip")
end
menu.add("• Limited").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyalimited.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyalimited.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyastarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyastarlight.zip")
end
menu.add("• Special Suzuhime").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyasuzuhime.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyasuzuhime.zip")
end
menu.add("• Special Valentine").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/miyavalentine.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/miyavalentine.zip")
end

function balmond.onClick()
  balmond.show()
end
balmond = PopupMenu(activity, balmond)
menu = balmond.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/balmondbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/balmondbackup.zip")
end
menu.add("• Elite").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/balmondelite.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/balmondelite.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/balmondspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/balmondspecial.zip")
end

function saber.onClick()
  saber.show()
end
saber = PopupMenu(activity, saber)
menu = saber.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/saberbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/saberbackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/saberstarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/saberstarlight.zip")
end
menu.add("• Epic Onimaru").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/saberonimaru.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/saberonimaru.zip")
end
menu.add("• Epic Squad").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/sabersquad.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/sabersquad.zip")
end
menu.add("• Legend").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/saberlegend.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/saberlegend.zip")
end

function alice.onClick()
  alice.show()
end
alice = PopupMenu(activity, alice)
menu = alice.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alicebackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alicebackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alicestarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alicestarlight.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alicespecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alicespecial.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/aliceepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/aliceepic.zip")
end

function nana.onClick()
  nana.show()
end
nana = PopupMenu(activity, nana)
menu = nana.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/nanabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/nanabackup.zip")
end
menu.add("• Elite Slumber Party").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/nanaelite.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/nanaelite.zip")
end

function tigreal.onClick()
  tigreal.show()
end
tigreal = PopupMenu(activity, tigreal)
menu = tigreal.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/tigrealbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/tigrealbackup.zip")
end
menu.add("• Elite Fallen Guard").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/tigrealelite.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/tigrealelite.zip")
end
menu.add("• Lightborn").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/tigreallightborn.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/tigreallightborn.zip")
end

function alucard.onClick()
  alucard.show()
end
alucard = PopupMenu(activity, alucard)
menu = alucard.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alubackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alubackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alustarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alustarlight.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/aluspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/aluspecial.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/aluepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/aluepic.zip")
end
menu.add("• Lightborn").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alulightborn.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alulightborn.zip")
end
menu.add("• Legend").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alulegend.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alulegend.zip")
end

function karina.onClick()
  karina.show()
end
karina = PopupMenu(activity, karina)
menu = karina.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/karinabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/karinabackup.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/karinaepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/karinaepic.zip")
end
menu.add("• K.O.F").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/karinakof.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/karinakof.zip")
end
menu.add("• Zodiak").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/karinazodiak.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/karinazodiak.zip")
end

function akai.onClick()
  akai.show()
end
akai = PopupMenu(activity, akai)
menu = akai.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/akaibackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/akaibackup.zip")
end

function franco.onClick()
  franco.show()
end
franco = PopupMenu(activity, franco)
menu = franco.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/francobackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/francobackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/francostarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/francostarlight.zip")
end
menu.add("• Special Master Chef").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/francomasterchef.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/francomasterchef.zip")
end
menu.add("• Special Wheatfield Nightmare").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/franconightmare.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/franconightmare.zip")
end
menu.add("• Epic Valhalla Ruler").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/francovalhallaruler.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/francovalhallaruler.zip")
end

function bruno.onClick()
  bruno.show()
end
bruno = PopupMenu(activity, bruno)
menu = bruno.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/brunobackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/brunobackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/brunospecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/brunospecial.zip")
end
menu.add("• Hero").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/brunohero.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/brunohero.zip")
end

function clint.onClick()
  clint.show()
end
clint = PopupMenu(activity, clint)
menu = clint.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/clintbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/clintbackup.zip")
end
menu.add("• Special Badminton").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/clintbadminton.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/clintbadminton.zip")
end
menu.add("• Special Guns and Roses").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/clintgunsandroses.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/clintgunsandroses.zip")
end
menu.add("• M2").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/clintm2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/clintm2.zip")
end

function rafaela.onClick()
  rafaela.show()
end
rafaela = PopupMenu(activity, rafaela)
menu = rafaela.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/rafaelabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/rafaelabackup.zip")
end
menu.add("• Elite").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/rafaelaelite.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/rafaelaelite.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/rafaelaepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/rafaelaepic.zip")
end

function eudora.onClick()
  eudora.show()
end
eudora = PopupMenu(activity, eudora)
menu = eudora.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/eudorabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/eudorabackup.zip")
end
menu.add("• Limited").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/eudoralimited.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/eudoralimited.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/eudoraepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/eudoraepic.zip")
end

function zilong.onClick()
  zilong.show()
end
zilong = PopupMenu(activity, zilong)
menu = zilong.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/zilongbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/zilongbackup.zip")
end
menu.add("• Epic Changbanpo Commander").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/zilongepic1.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/zilongepic1.zip")
end
menu.add("• Epic Glorious General").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/zilongepic2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/zilongepic2.zip")
end

function fanny.onClick()
  fanny.show()
end
fanny = PopupMenu(activity, fanny)
menu = fanny.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/fannybackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/fannybackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/fannystarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/fannystarlight.zip")
end
menu.add("• Special Lifeguard").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/fannybladedancer.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/fannybladedancer.zip")
end
menu.add("• Special Christmas").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/fannychristmas.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/fannychristmas.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/fannyskylark.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/fannyskylark.zip")
end
menu.add("• Lightborn").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/fannylightborn.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/fannylightborn.zip")
end

function layla.onClick()
  layla.show()
end
layla = PopupMenu(activity, layla)
menu = layla.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/laylabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/laylabackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/laylastarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/laylastarlight.zip")
end
menu.add("• Epic S.A.B.E.R Breacher").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/laylaepic1.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/laylaepic1.zip")
end
menu.add("• Epic Blazing Gun").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/laylaepic2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/laylaepic2.zip")
end

function minotaur.onClick()
  minotaur.show()
end
minotaur = PopupMenu(activity, minotaur)
menu = minotaur.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/minobackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/minobackup.zip")
end
menu.add("• Zodiak").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/minozodiak.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/minozodiak.zip")
end

function lolita.onClick()
  lolita.show()
end
lolita = PopupMenu(activity, lolita)
menu = lolita.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/lolibackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/lolibackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/lolispecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/lolispecial.zip")
end

function hayabusa.onClick()
  hayabusa.show()
end
hayabusa = PopupMenu(activity, hayabusa)
menu = hayabusa.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hayabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hayabackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hayaspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hayaspecial.zip")
end
menu.add("• Starlight Experiment 21").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hayastarlight1.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hayastarlight1.zip")
end
menu.add("• Starlight Biological Weapon").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hayastarlight2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hayastarlight2.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hayaepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hayaepic.zip")
end

function freya.onClick()
  freya.show()
end
freya = PopupMenu(activity, freya)
menu = freya.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/freyabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/freyabackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/freyaspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/freyaspecial.zip")
end
menu.add("• Epic War Angel").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/freyaepic1.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/freyaepic1.zip")
end
menu.add("• Epic Raven Shogun").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/freyaepic2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/freyaepic2.zip")
end

function gord.onClick()
  gord.show()
end
gord = PopupMenu(activity, gord)
menu = gord.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/gordbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/gordbackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/gordstarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/gordstarlight.zip")
end
menu.add("• Legend").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/gordlegend.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/gordlegend.zip")
end

function natalia.onClick()
  natalia.show()
end
natalia = PopupMenu(activity, natalia)
menu = natalia.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/natabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/natabackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/natastarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/natastarlight.zip")
end

function kagura.onClick()
  kagura.show()
end
kagura = PopupMenu(activity, kagura)
menu = kagura.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/kagurabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/kagurabackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/kaguraspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/kaguraspecial.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/kaguraepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/kaguraepic.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/kagurastarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/kagurastarlight.zip")
end

function chou.onClick()
  chou.show()
end
chou = PopupMenu(activity, chou)
menu = chou.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/choubackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/choubackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/chouspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/chouspecial.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/choustarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/choustarlight.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/chouepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/chouepic.zip")
end
menu.add("• K.O.F").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/choukof.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/choukof.zip")
end
menu.add("• Hero").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/chouhero.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/chouhero.zip")
end
menu.add("• Stun").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/choustun.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/choustun.zip")
end

function sun.onClick()
  sun.show()
end
sun = PopupMenu(activity, sun)
menu = sun.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/sunbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/sunbackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/sunspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/sunspecial.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/sunstarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/sunstarlight.zip")
end

function alpha.onClick()
  alpha.show()
end
alpha = PopupMenu(activity, alpha)
menu = alpha.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alphabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alphabackup.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/alphaepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/alphaepic.zip")
end

function ruby.onClick()
  ruby.show()
end
ruby = PopupMenu(activity, ruby)
menu = ruby.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/rubybackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/rubybackup.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/rubyepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/rubyepic.zip")
end

function yss.onClick()
  yss.show()
end
yss = PopupMenu(activity, yss)
menu = yss.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/yssbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/yssbackup.zip")
end
menu.add("• Elite").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/ysselite.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/ysselite.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/yssstarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/yssstarlight.zip")
end
menu.add("• Collector").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/ysscollector.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/ysscollector.zip")
end

function moskov.onClick()
  moskov.show()
end
moskov = PopupMenu(activity, moskov)
menu = moskov.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/moskovbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/moskovbackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/moskovspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/moskovspecial.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/moskovstarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/moskovstarlight.zip")
end
menu.add("• Epic Twilight Dragon").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/moskovepic1.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/moskovepic1.zip")
end
menu.add("• Epic Blood Spear").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/moskovepic2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/moskovepic2.zip")
end

function jhonson.onClick()
  jhonson.show()
end
jhonson = PopupMenu(activity, jhonson)
menu = jhonson.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/jhonbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/jhonbackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/jhonspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/jhonspecial.zip")
end
menu.add("• Epic S.A.B.E.R Automata").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/jhonepic1.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/jhonepic1.zip")
end
menu.add("• Epic Wreck King").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/jhonepic2.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/jhonepic2.zip")
end

function cyclops.onClick()
  cyclops.show()
end
cyclops = PopupMenu(activity, cyclops)
menu = cyclops.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/cycbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/cycbackup.zip")
end
menu.add("• Starlight").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/cycstarlight.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/cycstarlight.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/cycepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/cycepic.zip")
end
menu.add("• Star Wars").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/cycstarwars.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/cycstarwars.zip")
end

function estes.onClick()
  estes.show()
end
estes = PopupMenu(activity, estes)
menu = estes.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/estesbackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/estesbackup.zip")
end
menu.add("• Special").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/estesspecial.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/estesspecial.zip")
end
menu.add("• Epic").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/estesepic.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/estesepic.zip")
end

function hilda.onClick()
  hilda.show()
end
hilda = PopupMenu(activity, hilda)
menu = hilda.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hildabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hildabackup.zip")
end
menu.add("• Zodiak").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/hildazodiak.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/hildazodiak.zip")
end

function aurora.onClick()
  aurora.show()
end
aurora = PopupMenu(activity, aurora)
menu = aurora.Menu
menu.add("• Restore").onMenuItemClick = function()
  toolsdownload1("RESTORING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/aurorabackup.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/aurorabackup.zip")
end
menu.add("• Zodiak").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/aurorazodiak.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/aurorazodiak.zip")
end
menu.add("• K.O.F").onMenuItemClick = function()
  toolsdownload1("PATCHING","https://github.com/missfangg/X-HANNYA/blob/main/PATCHER/aurorakof.zip?raw=true","/storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/android/lua/aurorakof.zip")
end
