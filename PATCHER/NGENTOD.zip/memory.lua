function Exec(LUADIR)
import "com.androlua.util.RootUtil"
  local root = RootUtil()
if root.haveRoot()==true then
  zip4j.unZipDir(activity.getLuaDir("FUCKU.zip"),activity.getLuaDir("FUCKU"),"zzz55657983")
  BELAGUNJENG=activity.getLuaDir("FUCKU/"..LUADIR)
  os.execute("su -c chmod 777 "..BELAGUNJENG)
  Runtime.getRuntime().exec("su -c "..BELAGUNJENG)
  os.execute("su -c rm -rf "..activity.getLuaDir("FUCKU"))
else
  os.execute("chmod 777 "..BELAGUNJENG)
  Runtime.getRuntime().exec(""..BELAGUNJENG)
  os.execute("rm -rf "..activity.getLuaDir("FUCKU"))
end
end

  function radarmapicon.OnCheckedChangeListener()
    if radarmapicon.checked then
      Exec("libmime.so 55795")
    radarmapicon.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    radarmapicon.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libmime.so 55796")
    radarmapicon.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    radarmapicon.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end

  function radarmap.OnCheckedChangeListener()
    if radarmap.checked then
      Exec("libcjson.so 2")
    radarmap.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    radarmap.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libcjson.so 3")
    radarmap.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    radarmap.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


  function unlockskin.OnCheckedChangeListener()
    if unlockskin.checked then
      Exec("libmime.so 7295")
    unlockskin.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    unlockskin.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libmime.so 7296")
    unlockskin.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    unlockskin.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


  function esplock.OnCheckedChangeListener()
    if esplock.checked then
      Exec("libsocket.so 30")
    esplock.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    esplock.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libsocket.so 31")
    esplock.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    esplock.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


  function skillnocd.OnCheckedChangeListener()
    if skillnocd.checked then
      Exec("libsocket.so 8")
    skillnocd.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    skillnocd.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libsocket.so 9")
    skillnocd.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    skillnocd.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


  function spamchat.OnCheckedChangeListener()
    if spamchat.checked then
      Exec("libsocket.so 6")
    spamchat.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    spamchat.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libsocket.so 7")
    spamchat.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    spamchat.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


  function removegrass.OnCheckedChangeListener()
    if removegrass.checked then
      Exec("libmd5.so 2021")
    removegrass.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    removegrass.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libmd5.so 2022")
    removegrass.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    removegrass.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


function hidename.OnCheckedChangeListener()
    if hidename.checked then
      Exec("libsensor.so 1")
    hidename.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    hidename.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libsensor.so 2")
    hidename.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    hidename.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


function fixgrass.OnCheckedChangeListener()
    if fixgrass.checked then
      Exec("libthreads.so 2023")
    fixgrass.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    fixgrass.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libthreads.so 2024")
    fixgrass.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    fixgrass.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


function pushrank.OnCheckedChangeListener()
    if pushrank.checked then
      Exec("libmime.so 12396")
    pushrank.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    pushrank.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libmime.so 12397")
    pushrank.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    pushrank.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


function wallhack.OnCheckedChangeListener()
    if wallhack.checked then
      Exec("libmime.so 23394")
    wallhack.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    wallhack.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
      Exec("libmime.so 23395")
    wallhack.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    wallhack.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end




droneviewtop.setOnSeekBarChangeListener{
  onProgressChanged=function(view, progress)
    if progress==0 then
      text.setText("DRONE VERTICAL 0 X")
     Exec("libsocket.so 22")
      
     elseif progress==1 then
      text.setText("DRONE VERTICAL 2 X")
     Exec("libsocket.so 21")
      
     elseif progress==2 then
      text.setText("DRONE VERTICAL 4 X")
     Exec("libsocket.so 20")
      
     elseif progress==3 then
      text.setText("DRONE VERTICAL 6 X")
     Exec("libsocket.so 19")

     elseif progress==4 then
      text.setText("DRONE VERTICAL 8 X")
     Exec("libsocket.so 18")

     elseif progress==5 then
      text.setText("DRONE VERTICAL 10 X")
     Exec("libsocket.so 17")
     
     elseif progress==6 then
      text.setText("DRONE VERTICAL 12 X")
     Exec("libsocket.so 16")
     
     elseif progress==7 then
      text.setText("DRONE VERTICAL 14 X")
     Exec("libsocket.so 15")
     
     elseif progress==8 then
      text.setText("DRONE VERTICAL 16 X")
     Exec("libsocket.so 14")
     
     elseif progress==9 then
      text.setText("DRONE VERTICAL 18 X")
     Exec("libsocket.so 13")
     
     elseif progress==10 then
      text.setText("DRONE VERTICAL 20 X")
     Exec("libsocket.so 12")
    end
  end
}


droneviewside.setOnSeekBarChangeListener{
  onProgressChanged=function(view, progress)
    if progress==0 then
      text2.setText("DRONE HORIZONTAL 0 X")
     Exec("libsocket.so 42")
      
     elseif progress==1 then
      text2.setText("DRONE HORIZONTAL 2 X")
     Exec("libsocket.so 41")
      
     elseif progress==2 then
      text2.setText("DRONE HORIZONTAL 4 X")
     Exec("libsocket.so 40")
      
     elseif progress==3 then
      text2.setText("DRONE HORIZONTAL 6 X")
     Exec("libsocket.so 39")

     elseif progress==4 then
      text2.setText("DRONE HORIZONTAL 8 X")
     Exec("libsocket.so 38")

     elseif progress==5 then
      text2.setText("DRONE HORIZONTAL 10 X")
     Exec("libsocket.so 37")
     
     elseif progress==6 then
      text2.setText("DRONE HORIZONTAL 12 X")
     Exec("libsocket.so 36")
     
     elseif progress==7 then
      text2.setText("DRONE HORIZONTAL 14 X")
     Exec("libsocket.so 35")
     
     elseif progress==8 then
      text2.setText("DRONE HORIZONTAL 16 X")
     Exec("libsocket.so 34")
     
     elseif progress==9 then
      text2.setText("DRONE HORIZONTAL 18 X")
     Exec("libsocket.so 33")
     
     elseif progress==10 then
      text2.setText("DRONE HORIZONTAL 20 X")
     Exec("libsocket.so 32")
    end
  end
}


  function enemylag.onClick()
    if enemylag.checked then
      Exec("libsocket.so 1")
      TOASTTXT("ENEMY LAG ACTIVATED")
      CircleButton(enemylag,0xFFFF0000,10,4287187697)
     else
      Exec("libsocket.so 1")
      TOASTTXT("ENEMY LAG ACTIVATED")
      CircleButton(enemylag,0xFFFF0000,10,4287187697)
    end
  end


  function fix.onClick()
    if fix.checked then
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_043_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_032_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_003_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_024_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_004_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_041_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_007_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_015_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_042_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_027_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_044_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_001_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_019_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_021_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_046_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_009.unity3d")
      TOASTTXT("FIX BUG DRONE SUCCESSFUL")
      CircleButton(fix,0xFFFF0000,10,4287187697)
     else
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_043_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_032_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_003_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_024_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_004_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_041_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_007_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_015_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_042_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_027_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_044_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_001_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_019_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_021_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_046_add.unity3d")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/Scenes/android/PVP_009.unity3d")
      TOASTTXT("FIX BUG DRONE SUCCESSFUL")
      CircleButton(fix,0xFFFF0000,10,4287187697)
    end
  end


  

  function antiban.OnCheckedChangeListener()
    if antiban.checked then
import "java.io.File"--导入File类
File("storage/emulated/0/Android/data/com.mobile.legends/cache").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/UnityCache").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/BattleRecord").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA1"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/FightHistory").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA2"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/comlibs").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/X-HANNYA_COMLIBS"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/version/android/realversion.xml").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/version/android/X-HANNYA.xml"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/LiveSawHistory.bin").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/X-HANNYA.bin"))

File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ActivityBugReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ActivityBugReport.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_BattleExperienceReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_BattleExperienceReport.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_CountryBattle_Report.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_CountryBattle_Report.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_HistoryRecordListItemReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_HistoryRecordListItemReport.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_LiveReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_LiveReport.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report_BattleEnd_MC.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report_BattleEnd_MC.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportDetails.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportDetails.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportNew.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportNew.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page0.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page0.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page1.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page1.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page2.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page2.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page3.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page3.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_WarReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_WarReport.unity3d_X-HANNYA"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_YesterdayWarReport.unity3d").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_YesterdayWarReport.unity3d_X-HANNYA"))
    antiban.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
    antiban.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP));
     else
import "java.io.File"--导入File类
File("storage/emulated/0/Android/data/com.mobile.legends/X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/cache"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/UnityCache"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA1").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/BattleRecord"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA2").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/FightHistory"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/X-HANNYA_COMLIBS").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/comlibs"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/version/android/X-HANNYA.xml").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/version/android/realversion.xml"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/X-HANNYA.bin").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/LiveSawHistory.bin"))

File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ActivityBugReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ActivityBugReport.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_BattleExperienceReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_BattleExperienceReport.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_CountryBattle_Report.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_CountryBattle_Report.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_HistoryRecordListItemReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_HistoryRecordListItemReport.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_LiveReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_LiveReport.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report_BattleEnd_MC.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_Report_BattleEnd_MC.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportDetails.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportDetails.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportNew.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_ReportNew.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page0.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page0.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page1.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page1.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page2.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page2.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page3.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_SeasonReport_page3.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_WarReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_WarReport.unity3d"))
File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_YesterdayWarReport.unity3d_X-HANNYA").renameTo(File("storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/assets/UI/android/UI_YesterdayWarReport.unity3d"))
    antiban.ThumbDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP));
    antiban.TrackDrawable.setColorFilter(PorterDuffColorFilter(0xFF090707,PorterDuff.Mode.SRC_ATOP));
    end
  end


  function logs.onClick()
    if logs.checked then
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/cache/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/BattleRecord/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/FightHistory/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/LiveSawHistory.bin")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/UnityCache/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/code_cache/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/X-HANNYA/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/X-HANNYA/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA1/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA2/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/X-HANNYA.bin")
        TOASTTXT("CLEAR CACHE & LOGS SUCCESSFUL")
      CircleButton(logs,0xFFFF0000,10,4287187697)
     else
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/cache/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/BattleRecord/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/FightHistory/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/LiveSawHistory.bin")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/UnityCache/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/code_cache/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/X-HANNYA/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/X-HANNYA/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA1/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/X-HANNYA2/")
  os.execute("rm -rf /storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/android/X-HANNYA.bin")
       TOASTTXT("CLEAR CACHE & LOGS SUCCESSFUL")
      CircleButton(logs,0xFFFF0000,10,4287187697)
    end
  end