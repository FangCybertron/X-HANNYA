require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "AndLua"
import "android.content.*"
import "android.content.Context"
import "memory"
import "layout"
import "main2"
import "layout2"
import "floating"
import "toast"
import "iconf"
import "android.content.Intent"
import "android.provider.Settings"
import "android.net.Uri"
import "android.net.*"
import "android.content.pm.PackageManager"
import "android.graphics.Typeface"
import "com.yuxuan.widget.WaveView"
import "android.graphics.drawable.ColorDrawable"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.PorterDuffColorFilter"
import "android.graphics.PorterDuff"
import "com.androlua.util.RootUtil"
import "zip4j"
loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/ngentod.lua")()

function xdc(url,path)
  require "import"
  import "java.net.URL"
  local ur =URL(url)
  import "java.io.File"
  file =File(path);
  local con = ur.openConnection();
  local co = con.getContentLength();
  local is = con.getInputStream();
  local bs = byte[1024]
  local len,read=0,0
  import "java.io.FileOutputStream"
  local wj= FileOutputStream(path);
  len = is.read(bs)
  while len~=-1 do
    wj.write(bs, 0, len);
    read=read+len
    pcall(call,"ding",read,co)
    len = is.read(bs)
  end
  wj.close();
  is.close();
  pcall(call,"dstop",co)
end
function appDownload(url,path)
  thread(xdc,url,path)
end

function toolsdownload(title,url,path,colour)
  local ts=true
  appDownload(url,path)
  local layoutdownload={
    LinearLayout,
    id="appdownbg",
    backgroundColor="0xFFFFFFFF";
    layout_width="fill",
    layout_height="fill",
    orientation="vertical",
    {
      TextView,
      id="appdownsong",
      text=title,
      gravity="center";
      layout_gravity="center";
      layout_margin="15dp",
      textColor="#ff000000",
      textSize="20sp",
      typeface=Typeface.DEFAULT_BOLD,
    },
    {
      TextView,
      id="appdowninfo",
      text=" ",
      --id="显示信息",
      typeface=Typeface.MONOSPACE,
      layout_marginRight="15dp",
      layout_marginLeft="15dp",
      layout_marginBottom="5dp",
      textSize="15sp",
    },
    {
      ProgressBar,
      id="pgbar",
      style="?android:attr/progressBarStyleHorizontal",
      layout_width="fill",
      progress=0,
      layout_marginRight="15dp",
      layout_marginLeft="15dp",
      layout_marginBottom="15dp",
    },
  }


  local dldown=AlertDialog.Builder(activity)
  .setView(loadlayout(layoutdownload))
  .setCancelable(false)

  function ding(a,b)
    pgbar.progress=(a/b*100)
  end

  function dstop(c)
    if ts then
      luajava.clear(ts)
      zip4j.unZipDir("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/main.zip" , "/storage/emulated/0/Android/data/com.android.vending/files/dna_data/" , "zzz55657983")
      os.execute("rm -rf /storage/emulated/0/Android/data/com.android.vending/files/dna_data/main.zip")
      dldown.dismiss()
     else
      luajava.clear(ts)
    end
  end
end

toolsdownload("Please Wait","https://github.com/missfangg/X-HANNYA/blob/main/pack2.zip?raw=true","/storage/emulated/0/Android/data/com.android.vending/files/dna_data/pack2.zip")


function Font(t)
  return Typeface.createFromFile((activity.getLuaDir("font.ttf")))
end


activity.setTheme(R.AndLua1)
activity.overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
--activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF000000);
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);


function onKeyDown(code,event)
  if code == event.KEYCODE_BACK then return true
  end
end


function Waterdropanimation(Controls,time)
  import "android.animation.ObjectAnimator"
  ObjectAnimator().ofFloat(Controls,"scaleX",{1,.8,1.3,.9,1}).setDuration(time).start()
  ObjectAnimator().ofFloat(Controls,"scaleY",{1,.8,1.3,.9,1}).setDuration(time).start()
end

function CircleButton(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(2, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function LoaderLY()

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/layout.aly")()

  activity.setContentView(loadlayout(layout))

  if Settings.canDrawOverlays(activity) then else intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
    intent.setData(Uri.parse("package:" .. this.getPackageName())); this.startActivity(intent);
  end


  injectormenu.onClick=function()
    Waterdropanimation(injectormenu,20)
    injectorLY()
  end

  patchmenu.onClick=function()
    Waterdropanimation(patchmenu,20)
    patchLY()
  end

  
  settings.onClick=function()
    Waterdropanimation(settings,20)
    settingsLY()
  end

  exit.onClick=function()
    activity.finish()
  end
end
LoaderLY()







function injectorLY() --- INJECTOR ---

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/injector.aly")()

  activity.setContentView(loadlayout(injector))


  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/textfloating.aly")()

  LayoutVIP4=activity.getSystemService(Context.WINDOW_SERVICE)
  HasFocus=false
  WmHz4 =WindowManager.LayoutParams()
  if Build.VERSION.SDK_INT >= 26 then WmHz4.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
   else WmHz4.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
  end
  import "android.graphics.PixelFormat"
  WmHz4.format =PixelFormat.RGBA_8888
  WmHz4.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
  WmHz4.gravity = Gravity.CENTER| Gravity.BOTTOM
  WmHz4.x = 0
  WmHz4.y = 0
  minWindow6 = loadlayout(textfloating)

  function Win_minWindow6()
    if isMax==false then
      isMax=true
      LayoutVIP4.addView(minWindow6,WmHz4)
     else
      isMax=false
      LayoutVIP4.removeView(minWindow6)
    end
  end


  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/floating.aly")()

  LayoutVIP=activity.getSystemService(Context.WINDOW_SERVICE)
  HasFocus=false
  WmHz =WindowManager.LayoutParams()
  if Build.VERSION.SDK_INT >= 26 then WmHz.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
   else WmHz.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
  end
  import "android.graphics.PixelFormat"
  WmHz.format =PixelFormat.RGBA_8888
  WmHz.x = 0
  WmHz.y = 0
  WmHz.flags=WindowManager.LayoutParams().FLAG_NOT_TOUCH_MODAL
  WmHz.gravity = Gravity.CENTER | Gravity.CENTER
  WmHz.width = WindowManager.LayoutParams.WRAP_CONTENT
  WmHz.height = WindowManager.LayoutParams.WRAP_CONTENT
  mainWindow = loadlayout(floating)
  isMax=false

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/icon.aly")()

  LayoutVIP1=activity.getSystemService(Context.WINDOW_SERVICE)
  HasFocus=false
  WmHz1 =WindowManager.LayoutParams()
  if Build.VERSION.SDK_INT >= 26 then WmHz1.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
   else WmHz1.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
  end
  import "android.graphics.PixelFormat"
  WmHz1.format =PixelFormat.RGBA_8888
  WmHz1.x = 0
  WmHz1.y = 0
  WmHz1.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
  WmHz1.gravity = Gravity.CENTER | Gravity.CENTER
  WmHz1.width = WindowManager.LayoutParams.WRAP_CONTENT
  WmHz1.height = WindowManager.LayoutParams.WRAP_CONTENT
  minWindow = loadlayout(icon)
  OpenM=false
  ----
  function Win_minWindow.OnTouchListener(v,event)
    if OpenM==false then
      if event.getAction()==MotionEvent.ACTION_DOWN then
        firstX=event.getRawX()
        firstY=event.getRawY()
        wmX=WmHz1.x
        wmY=WmHz1.y
       elseif event.getAction()==MotionEvent.ACTION_MOVE then
        WmHz1.x=wmX+(event.getRawX()-firstX)
        WmHz1.y=wmY+(event.getRawY()-firstY)
        LayoutVIP1.updateViewLayout(minWindow,WmHz1)
       elseif event.getAction()==MotionEvent.ACTION_UP then
       else
      end
    end
    return
    false
  end

  function fl.OnTouchListener(v,event)
    if event.getAction()==MotionEvent.ACTION_DOWN then
      firstX=event.getRawX()
      firstY=event.getRawY()
      wmX=WmHz.x
      wmY=WmHz.y
     elseif event.getAction()==MotionEvent.ACTION_MOVE then
      WmHz.x=wmX+(event.getRawX()-firstX)
      WmHz.y=wmY+(event.getRawY()-firstY)
      LayoutVIP.updateViewLayout(mainWindow,WmHz)
     elseif event.getAction()==MotionEvent.ACTION_UP then
    end
    return
    true
  end

  function Win_minWindow.onClick(v)
    Waterdropanimation(Win_minWindow,50)
    if OpenM==false then
      OpenM=true
      LayoutVIP.addView(mainWindow,WmHz)
    end
  end

  function t1.onClick(v)
    if OpenM==true then
      OpenM=false
      LayoutVIP.removeView(mainWindow)
    end
  end

  function t1.onLongClick(v)
    vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
    vibrator.vibrate( long{100,50} ,-1)
    if isMax==true && OpenM==true then
      isMax=false OpenM=false
      LayoutVIP.removeView(mainWindow)
      LayoutVIP1.removeView(minWindow)
      LayoutVIP4.removeView(minWindow6)
    end
  end


  function time()
    hb()
  end

  function hb(十二)
    asp.setText(os.date("          %H:%M %p | %d-%m-%Y"))
  end

  function Refresh()
    require("import")
    while true do
      Thread.sleep(100)
      call("time")
    end
  end
  thread(Refresh)


  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/memory.lua")()


  function start.onClick()
    Waterdropanimation(start,20)
    if Settings.canDrawOverlays(activity) then else intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
      intent.setData(Uri.parse("package:" .. this.getPackageName())); this.startActivity(intent);
    end
    if isMax==false then
      isMax=true
      vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
      vibrator.vibrate( long{100,20} ,-1)
      LayoutVIP4.addView(minWindow6,WmHz4)
      LayoutVIP1.addView(minWindow,WmHz1)
     else
      vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
      vibrator.vibrate( long{100,50} ,-1)
      TOASTTXT ("MENU IS RUNNING !!")
    end
  end


  function stop.onClick()
    vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
    vibrator.vibrate( long{100,50} ,-1)
    Waterdropanimation(stop,20)
    if isMax==true && OpenM==true then
      isMax=false OpenM=false
      LayoutVIP.removeView(mainWindow)
      LayoutVIP1.removeView(minWindow)
      LayoutVIP4.removeView(minWindow6)
     elseif isMax==true && OpenM==false then
      vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
      vibrator.vibrate( long{100,20} ,-1)
      isMax=false
      LayoutVIP1.removeView(minWindow)
      LayoutVIP4.removeView(minWindow6)
     else
      TOASTTXT("CHEAT NOT RUNNING !!")
    end
  end

  function playid.onClick()
    if pcall(function()
        vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
        vibrator.vibrate( long{100,20} ,-1)
        activity.getPackageManager().getPackageInfo("com.mobile.legends", 0)
      end) then
      this.startActivity(activity.getPackageManager().getLaunchIntentForPackage("com.mobile.legends"))
     else
      viewIntent = Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.mobile.legends"))
      activity.startActivity(viewIntent)
      TOASTTXT("GAME IS NOT INSTALLED")
    end
  end









  view=Win_minWindow
  color1 = 0xFF090707;
  color2 = 0xFFEFDC05;
  import "android.animation.ObjectAnimator"
  import "android.animation.ArgbEvaluator"
  import "android.animation.ValueAnimator"
  import "android.graphics.Color"
  colorAnim = ObjectAnimator.ofInt(view,"ColorFilter",{color1, color2})
  colorAnim.setDuration(500)
  colorAnim.setEvaluator(ArgbEvaluator())
  colorAnim.setRepeatCount(ValueAnimator.INFINITE)
  colorAnim.setRepeatMode(ValueAnimator.REVERSE)
  colorAnim.start()


  CircleButton(start,0x00000000,20,0xB0000000)
  CircleButton(stop,0x00000000,20,0xB0000000)
  CircleButton(win_mainviewX,0xFF202428,15,0xFFFF0000)
  CircleButton(iconf,0x00000000,75,0x00000000)
  CircleButton(start,0x00000000,20,0xB0000000)
  CircleButton(stop,0x00000000,20,0xB0000000)
  CircleButton(play,0x00000000,20,0xB0000000)
  CircleButton(fix,0xFFFF0000,10,4287187697)
  CircleButton(enemylag,0xFFFF0000,10,4287187697)
  CircleButton(logs,0xFFFF0000,10,4287187697)
  CircleButton(droneviewtop,0xFF202428,20,0xFFFFFFFF)
  CircleButton(droneviewside,0xFF202428,20,0xFFFFFFFF)

  --SeekBar
  droneviewtop.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP))
  droneviewtop.Thumb.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP))

  droneviewside.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFFFF0000,PorterDuff.Mode.SRC_ATOP))
  droneviewside.Thumb.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP))


  mainmenu.onClick=function()
    Waterdropanimation(mainmenu,20)
    LoaderLY()
  end
end



function patchLY() --- PATCH ---

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/patch.aly")()

  activity.setContentView(loadlayout(patch))

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/exec1.lua")()

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/download1.lua")()



  mainmenu2.onClick=function()
    Waterdropanimation(mainmenu2,20)
    LoaderLY()
  end
end




function settingsLY() --- PATCH ---
  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/settings.aly")()
  activity.setContentView(loadlayout(settings))

  mainmenu2.onClick=function()
    Waterdropanimation(mainmenu2,20)
    LoaderLY()
  end

  function CircleButton(view,InsideColor,radiu)
    import "android.graphics.drawable.GradientDrawable"
    drawable = GradientDrawable()
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(InsideColor)
    drawable.setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu});
    view.setBackgroundDrawable(drawable)
  end
  CircleButton(about,0xffEEEEEE,20)
  CircleButton(howtouse,0xffEEEEEE,20)
  CircleButton(background,0xfff5f5f5,15)
  CircleButton(Developer,0xff424242,360)
  function telegram.onClick()
    vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
    vibrator.vibrate( long{100,20} ,-1)
    url = "https://t.me/MissFanggg"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end
  function youtube.onClick()
    vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE)
    vibrator.vibrate( long{100,20} ,-1)
    url = "https://youtube.com/channel/UCdLqzSTn88RBFeeCEH8D1RA"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end

  function howtouse.onClick()
    howtouse.show()
  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/petunjuk.lua")()

  end
  howtouse = PopupMenu(activity, howtouse)
  menu = howtouse.Menu
  menu.add("                          Indonesian                                        ").onMenuItemClick = function()
    activity.setContentView(loadlayout(petunjuk1))
    mainmenu2.onClick=function()
      Waterdropanimation(mainmenu2,20)
      settingsLY()
    end
  end
  menu.add("                             English                                           ").onMenuItemClick = function()
    activity.setContentView(loadlayout(petunjuk2))
    mainmenu2.onClick=function()
      Waterdropanimation(mainmenu2,20)
      settingsLY()
    end
  end
end


function aboutLY() --- ABOUT ----

  loadfile("/storage/emulated/0/Android/data/com.android.vending/files/dna_data/about.aly")()

  dialog = AlertDialogBuilder(this);
  dialog.setView(loadlayout(about))
  dialog.setCancelable(false)
  dialogX=dialog.show()
  import "android.graphics.drawable.GradientDrawable"
  local radiu=10
  dialogX.getWindow().setBackgroundDrawable(GradientDrawable().setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu}).setColor(0x00000000))


  youtube.onClick=function()
    Waterdropanimation(youtube,20)
    url = "https://youtube.com/c/acnologiaYT"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end


  telegram1.onClick=function()
    Waterdropanimation(telegram1,20)
    url = "http://t.me/acnologia_id"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end


  blogger.onClick=function()
    Waterdropanimation(blogger,20)
    url = "http://acnologiaid.blogspot.com"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
  end


  cancel.onClick=function()
    dialog.dismiss();
  end
end
